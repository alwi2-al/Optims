# Vendored from https://github.com/ethereum-optimism/superchain-registry

Do not manually edit these files