# configs

This directory contains configuration source files for OP Stack chains, arranged by superchain. They can be used to configure OP Stack consensus clients (e.g. op-node).

Each chain configuration file in this directory contains configuration data that was generated from the [ops](../../ops/) code.

See also extra data stored per-chain in the [extra](../extra) folder
