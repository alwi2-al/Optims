package opsimulator

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"strconv"
	"sync/atomic"

	ophttp "github.com/ethereum-optimism/optimism/op-service/httputil"
	"github.com/ethereum-optimism/optimism/op-service/predeploys"
	"github.com/ethereum-optimism/optimism/op-service/tasks"

	"github.com/ethereum-optimism/supersim/bindings"
	"github.com/ethereum-optimism/supersim/config"
	"github.com/ethereum-optimism/supersim/interop"
	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/log"
	"github.com/ethereum/go-ethereum/rpc"
)

const (
	l2NativeSuperchainERC20Addr = "0x420beeF000000000000000000000000000000001"
)

type OpSimulator struct {
	config.Chain // the chain that op-sim is wrapping

	log log.Logger

	l1Chain config.Chain

	interopDelay uint64

	// Long running tasks
	bgTasks       tasks.Group
	bgTasksCtx    context.Context
	bgTasksCancel context.CancelFunc
	peers         map[uint64]config.Chain

	host           string
	port           uint64
	httpServer     *ophttp.HTTPServer
	crossL2Inbox   *bindings.CrossL2Inbox
	l1BlockInterop *bindings.L1BlockInterop

	ethClient *ethclient.Client

	stopped atomic.Bool
}

// OpSimulator wraps around the l2 chain. By embedding `Chain`, it also implements the same inteface
func New(log log.Logger, closeApp context.CancelCauseFunc, port uint64, host string, l1Chain, l2Chain config.Chain, peers map[uint64]config.Chain, interopDelay uint64) *OpSimulator {
	bgTasksCtx, bgTasksCancel := context.WithCancel(context.Background())

	return &OpSimulator{
		Chain: l2Chain,

		log:          log.New("chain.id", l2Chain.Config().ChainID),
		port:         port,
		host:         host,
		l1Chain:      l1Chain,
		interopDelay: interopDelay,

		bgTasksCtx:    bgTasksCtx,
		bgTasksCancel: bgTasksCancel,
		bgTasks: tasks.Group{
			HandleCrit: func(err error) {
				log.Error("opsim bg task failed", "err", err)
				closeApp(err)
			},
		},

		peers: peers,
	}
}

func (opSim *OpSimulator) Start(ctx context.Context) error {
	mux := http.NewServeMux()
	mux.Handle("/", corsHandler(opSim.handler(ctx)))

	hs, err := ophttp.StartHTTPServer(net.JoinHostPort(opSim.host, fmt.Sprintf("%d", opSim.port)), mux)
	if err != nil {
		return fmt.Errorf("failed to start HTTP RPC server: %w", err)
	}

	cfg := opSim.Config()
	opSim.log.Debug("started opsimulator", "name", cfg.Name, "chain.id", cfg.ChainID, "addr", hs.Addr())
	opSim.httpServer = hs

	if opSim.port == 0 {
		_, portStr, err := net.SplitHostPort(hs.Addr().String())
		if err != nil {
			panic(fmt.Errorf("failed to parse address: %w", err))
		}

		port, err := strconv.ParseUint(portStr, 10, 64)
		if err != nil {
			panic(fmt.Errorf("unexpected opsimulator listening port: %w", err))
		}
		opSim.port = port
	}

	ethClient, err := ethclient.Dial(opSim.Endpoint())
	if err != nil {
		return fmt.Errorf("failed to create eth client: %w", err)
	}
	opSim.ethClient = ethClient

	crossL2Inbox, err := bindings.NewCrossL2Inbox(predeploys.CrossL2InboxAddr, ethClient)
	if err != nil {
		return fmt.Errorf("failed to create cross L2 inbox: %w", err)
	}
	opSim.crossL2Inbox = crossL2Inbox

	l1BlockInterop, err := bindings.NewL1BlockInterop(predeploys.L1BlockAddr, ethClient)
	if err != nil {
		return fmt.Errorf("failed to create L1 block interop: %w", err)
	}
	opSim.l1BlockInterop = l1BlockInterop

	opSim.startBackgroundTasks()
	return nil
}

func (opSim *OpSimulator) Stop(ctx context.Context) error {
	if opSim.stopped.Load() {
		return errors.New("already stopped")
	}
	if !opSim.stopped.CompareAndSwap(false, true) {
		return nil // someone else stopped
	}

	opSim.bgTasksCancel()
	if opSim.httpServer != nil {
		return opSim.httpServer.Stop(ctx)
	}

	return nil
}

func (opSim *OpSimulator) EthClient() *ethclient.Client {
	return opSim.ethClient
}

func (opSim *OpSimulator) startBackgroundTasks() {
	// Relay deposit tx from L1 to L2
	opSim.bgTasks.Go(func() error {
		depositTxCh := make(chan *types.DepositTx)
		portalAddress := opSim.Config().L2Config.L1Addresses.OptimismPortalProxy
		sub, err := SubscribeDepositTx(context.Background(), opSim.l1Chain.EthClient(), *portalAddress, depositTxCh)
		if err != nil {
			return fmt.Errorf("failed to subscribe to deposit tx: %w", err)
		}

		chainId := opSim.Config().ChainID

		for {
			select {
			case dep := <-depositTxCh:
				depTx := types.NewTx(dep)
				opSim.log.Debug("observed deposit event on L1", "hash", depTx.Hash().String())

				clnt := opSim.Chain.EthClient()
				if err := clnt.SendTransaction(opSim.bgTasksCtx, depTx); err != nil {
					opSim.log.Error("failed to submit deposit tx to chain: %w", "chain.id", chainId, "err", err)
				}

				opSim.log.Info("OptimismPortal#depositTransaction", "l2TxHash", depTx.Hash().String())

			case <-opSim.bgTasksCtx.Done():
				sub.Unsubscribe()
				close(depositTxCh)
				return nil
			}
		}
	})

	// Log SuperchainERC20 events
	opSim.bgTasks.Go(func() error {
		contracts := []struct {
			name    string
			address common.Address
		}{
			{"SuperchainWETH", predeploys.SuperchainWETHAddr},
			{"L2NativeSuperchainERC20", common.HexToAddress(l2NativeSuperchainERC20Addr)},
		}

		for _, c := range contracts {
			contract, err := bindings.NewSuperchainERC20(c.address, opSim.Chain.EthClient())
			if err != nil {
				return fmt.Errorf("failed to create %s contract: %w", c.name, err)
			}

			mintEventChan := make(chan *bindings.SuperchainERC20CrosschainMint)
			burnEventChan := make(chan *bindings.SuperchainERC20CrosschainBurn)

			mintSub, err := contract.WatchCrosschainMint(&bind.WatchOpts{Context: opSim.bgTasksCtx}, mintEventChan, nil, nil)
			if err != nil {
				return fmt.Errorf("failed to subscribe to %s#CrosschainMint: %w", c.name, err)
			}

			burnSub, err := contract.WatchCrosschainBurn(&bind.WatchOpts{Context: opSim.bgTasksCtx}, burnEventChan, nil, nil)
			if err != nil {
				return fmt.Errorf("failed to subscribe to %s#CrosschainBurn: %w", c.name, err)
			}

			for {
				select {
				case event := <-mintEventChan:
					opSim.log.Info(c.name+"#CrosschainMint", "to", event.To, "amount", event.Amount, "sender", event.Sender)
				case event := <-burnEventChan:
					opSim.log.Info(c.name+"#CrosschainBurn", "from", event.From, "amount", event.Amount, "sender", event.Sender)
				case <-opSim.bgTasksCtx.Done():
					mintSub.Unsubscribe()
					burnSub.Unsubscribe()
					return nil
				}
			}
		}
		return nil
	})

	// Log SuperchainTokenBridge events
	opSim.bgTasks.Go(func() error {
		superchainTokenBridge, err := bindings.NewSuperchainTokenBridge(predeploys.SuperchainTokenBridgeAddr, opSim.Chain.EthClient())
		if err != nil {
			return fmt.Errorf("failed to create SuperchainTokenBridge contract: %w", err)
		}

		sendEventChan := make(chan *bindings.SuperchainTokenBridgeSendERC20)
		sendSub, err := superchainTokenBridge.WatchSendERC20(&bind.WatchOpts{Context: opSim.bgTasksCtx}, sendEventChan, nil, nil, nil)
		if err != nil {
			return fmt.Errorf("failed to subscribe to SuperchainTokenBridge#SendERC20: %w", err)
		}

		relayEventChan := make(chan *bindings.SuperchainTokenBridgeRelayERC20)
		relaySub, err := superchainTokenBridge.WatchRelayERC20(&bind.WatchOpts{Context: opSim.bgTasksCtx}, relayEventChan, nil, nil, nil)
		if err != nil {
			return fmt.Errorf("failed to subscribe to SuperchainTokenBridge#RelayERC20: %w", err)
		}

		for {
			select {
			case event := <-sendEventChan:
				opSim.log.Info("SuperchainTokenBridge#SendERC20", "token", event.Token, "from", event.From, "to", event.To, "amount", event.Amount, "destination", event.Destination)
			case event := <-relayEventChan:
				opSim.log.Info("SuperchainTokenBridge#RelayERC20", "token", event.Token, "from", event.From, "to", event.To, "amount", event.Amount, "source", event.Source)
			case <-opSim.bgTasksCtx.Done():
				sendSub.Unsubscribe()
				relaySub.Unsubscribe()
				return nil
			}
		}
	})

	// Log SuperchainWETH events
	opSim.bgTasks.Go(func() error {
		superchainWeth, err := bindings.NewSuperchainWETH(predeploys.SuperchainWETHAddr, opSim.Chain.EthClient())
		if err != nil {
			return fmt.Errorf("failed to create SuperchainWETH contract: %w", err)
		}

		sendEventChan := make(chan *bindings.SuperchainWETHSendETH)
		sendSub, err := superchainWeth.WatchSendETH(&bind.WatchOpts{Context: opSim.bgTasksCtx}, sendEventChan, nil, nil)
		if err != nil {
			return fmt.Errorf("failed to subscribe to SuperchainWETH#SendETH: %w", err)
		}

		relayEventChan := make(chan *bindings.SuperchainWETHRelayETH)
		relaySub, err := superchainWeth.WatchRelayETH(&bind.WatchOpts{Context: opSim.bgTasksCtx}, relayEventChan, nil, nil)
		if err != nil {
			return fmt.Errorf("failed to subscribe to SuperchainWETH#RelayETH: %w", err)
		}

		for {
			select {
			case event := <-sendEventChan:
				opSim.log.Info("SuperchainWETH#SendETH", "from", event.From, "to", event.To, "amount", event.Amount, "destination", event.Destination)
			case event := <-relayEventChan:
				opSim.log.Info("SuperchainWETH#RelayETH", "from", event.From, "to", event.To, "amount", event.Amount, "source", event.Source)
			case <-opSim.bgTasksCtx.Done():
				sendSub.Unsubscribe()
				relaySub.Unsubscribe()
				return nil
			}
		}
	})
}

func (opSim *OpSimulator) handler(ctx context.Context) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		// setup an intermediate buffer so the request body is inspectable
		var buf bytes.Buffer
		body := io.TeeReader(r.Body, &buf)
		r.Body = io.NopCloser(&buf)

		// decode the fields we're interested in inspecting
		msgs, isBatchRequest, err := readJsonMessages(body)
		if err != nil {
			http.Error(w, fmt.Sprintf("Failed to parse JSON-RPC request: %s", err), http.StatusBadRequest)
			return
		}

		rpcClient := opSim.Chain.EthClient().Client()
		batchRes := make([]*jsonRpcMessage, len(msgs))
		for i, msg := range msgs {
			if msg.Method == "eth_sendRawTransaction" {
				var params []hexutil.Bytes
				if err := json.Unmarshal(msg.Params, &params); err != nil {
					opSim.log.Error("bad params sent to eth_sendRawTransaction", "err", err)
					batchRes[i] = msg.errorResponse(err)
					continue
				}
				if len(params) != 1 {
					opSim.log.Error("eth_sendRawTransaction request has invalid number of params")
					batchRes[i] = msg.errorResponse(&jsonError{Code: InvalidParams, Message: "invalid request params"})
					continue
				}

				tx := new(types.Transaction)
				if err := tx.UnmarshalBinary(params[0]); err != nil {
					opSim.log.Error("failed to decode transaction data", "err", err)
					batchRes[i] = msg.errorResponse(err)
					continue
				}

				txHash := tx.Hash()

				// Deposits should not be directly sendable to the L2
				if tx.IsDepositTx() {
					opSim.log.Error("rejecting deposit tx", "hash", txHash.String())
					batchRes[i] = msg.errorResponse(&jsonError{Code: InvalidParams, Message: "cannot process deposit tx"})
					continue
				}

				// Simulate the tx.
				logs, err := opSim.SimulatedLogs(ctx, tx)
				if err != nil {
					opSim.log.Warn("failed to simulate transaction!!!", "err", err, "hash", txHash)
					batchRes[i] = msg.errorResponse(&jsonError{Code: InvalidParams, Message: "failed tx simulation"})
					continue
				} else {
					if err := opSim.checkInteropInvariants(ctx, logs); err != nil {
						opSim.log.Error("unable to statisfy interop invariants within transaction", "err", err, "hash", txHash)
						batchRes[i] = msg.errorResponse(&jsonError{Code: InvalidParams, Message: err.Error()})
						continue
					}
				}
			}

			// NOTE: This fans out the batch request into individual requests. To match expected behavior, this
			// should filter out messages that are invalid and reconstruct a single batch request to forward
			var jsonErr *jsonError
			batchRes[i], jsonErr = forwardRPCRequest(ctx, rpcClient, msg)
			if jsonErr != nil {
				batchRes[i] = msg.errorResponse(jsonErr)
			}
		}

		var encdata []byte
		if isBatchRequest {
			encdata, err = json.Marshal(batchRes)
		} else {
			encdata, err = json.Marshal(batchRes[0])
		}

		// encoding error
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		// write to response
		w.Header().Set("Content-Length", strconv.Itoa(len(encdata)))
		w.Header().Set("Transfer-Encoding", "identity")
		if _, err := w.Write(encdata); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		// trigger a flush if applicable
		if f, ok := w.(http.Flusher); ok {
			f.Flush()
		}
	}
}

// Forward a JSON-RPC request to the Geth RPC server
func forwardRPCRequest(ctx context.Context, rpcClient *rpc.Client, req *jsonRpcMessage) (*jsonRpcMessage, *jsonError) {
	var result json.RawMessage
	var params []interface{}
	if len(req.Params) > 0 {
		if err := json.Unmarshal(req.Params, &params); err != nil {
			return nil, &jsonError{Code: InvalidParams, Message: err.Error()}
		}
	}

	if err := rpcClient.CallContext(ctx, &result, req.Method, params...); err != nil {
		return nil, toJsonError(err)
	}
	return &jsonRpcMessage{Version: vsn, Result: result, ID: req.ID}, nil
}

func (opSim *OpSimulator) checkInteropInvariants(ctx context.Context, logs []types.Log) error {
	var executingMessages []*bindings.CrossL2InboxExecutingMessage
	for _, log := range logs {
		if !interop.IsExecutingMessageLog(&log) {
			continue
		}

		executingMessage, err := opSim.crossL2Inbox.ParseExecutingMessage(log)
		if err != nil {
			return fmt.Errorf("failed to decode executing messages from transaction logs: %w", err)
		}
		executingMessages = append(executingMessages, executingMessage)
	}

	if len(executingMessages) >= 1 {
		for _, executingMessage := range executingMessages {
			identifier := executingMessage.Id
			sourceChain, ok := opSim.peers[identifier.ChainId.Uint64()]
			if !ok {
				return fmt.Errorf("no chain found for chain id: %d", identifier.ChainId)
			}

			sourceClient := sourceChain.EthClient()
			identifierBlockHeader, err := sourceClient.HeaderByNumber(ctx, identifier.BlockNumber)
			if err != nil {
				return fmt.Errorf("failed to fetch executing message block: %w", err)
			}

			if identifier.Timestamp.Cmp(new(big.Int).SetUint64(identifierBlockHeader.Time)) != 0 {
				return fmt.Errorf("executing message identifier does not match block timestamp: %w", err)
			}

			fq := ethereum.FilterQuery{Addresses: []common.Address{identifier.Origin}, FromBlock: identifier.BlockNumber, ToBlock: identifier.BlockNumber}
			logs, err := sourceClient.FilterLogs(ctx, fq)
			if err != nil {
				return fmt.Errorf("failed to fetch initiating message logs: %w", err)
			}

			var initiatingMessageLogs []types.Log
			for _, log := range logs {
				logIndex := big.NewInt(int64(log.Index))
				if logIndex.Cmp(identifier.LogIndex) == 0 {
					initiatingMessageLogs = append(initiatingMessageLogs, log)
				}
			}

			if len(initiatingMessageLogs) == 0 {
				return fmt.Errorf("initiating message not found")
			}

			// Since we look for a log at a specific index, this should never be more than 1.
			if len(initiatingMessageLogs) > 1 {
				return fmt.Errorf("unexpected number of initiating messages found: %d", len(initiatingMessageLogs))
			}

			initiatingMsgPayloadHash := crypto.Keccak256Hash(interop.ExecutingMessagePayloadBytes(&initiatingMessageLogs[0]))
			if common.BytesToHash(executingMessage.MsgHash[:]).Cmp(initiatingMsgPayloadHash) != 0 {
				return fmt.Errorf("executing and initiating message fields are not equal")
			}

			interopStart, err := opSim.crossL2Inbox.InteropStart(&bind.CallOpts{})
			if err != nil {
				return fmt.Errorf("failed to fetch interop start: %w", err)
			}
			if interopStart.Cmp(identifier.Timestamp) > 0 {
				return fmt.Errorf("interop start is greater than initiating message timestamp")
			}

			isInDependencySet, err := opSim.l1BlockInterop.IsInDependencySet(&bind.CallOpts{}, big.NewInt(identifier.ChainId.Int64()))
			if err != nil {
				return fmt.Errorf("failed to check if chain id is in dependency set: %w", err)
			}
			if !isInDependencySet {
				return fmt.Errorf("chain id is not in dependency set")
			}

			if opSim.interopDelay != 0 {
				header, err := opSim.ethClient.HeaderByNumber(ctx, nil)
				if err != nil {
					return fmt.Errorf("failed to fetch executing block header: %w", err)
				}

				if header.Time < identifierBlockHeader.Time+opSim.interopDelay {
					return fmt.Errorf("not enough time has passed since initiating message (need %ds, got %ds)",
						opSim.interopDelay, header.Time-identifierBlockHeader.Time)
				}
			}
		}
	}

	return nil
}

// Overridden such that the port field can appropiately be set
func (opSim *OpSimulator) Config() *config.ChainConfig {
	// we dereference the config so that a copy is made. This is only okay since
	// the field were modifying is a non-pointer fields
	cfg := *opSim.Chain.Config()
	cfg.Port = opSim.port
	return &cfg
}

// Overridden such that the correct port is used
func (opSim *OpSimulator) Endpoint() string {
	return fmt.Sprintf("http://%s:%d", opSim.host, opSim.port)
}

func corsHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}

		next.ServeHTTP(w, r)
	})
}
