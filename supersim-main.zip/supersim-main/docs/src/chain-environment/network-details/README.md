# Network details

By default, two OP Stack systems will be spun up in vanilla mode

- OPChainA (chainID 901)
- OPChainB (chainID 902)

Both "roll up" into a single L1 chain (chainID 900).
