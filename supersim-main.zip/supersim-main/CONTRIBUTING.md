### Contributions Related to Spelling and Grammar

At this time, we will not be accepting contributions that primarily fix
spelling, stylistic or grammatical errors in documentation, code or elsewhere.

Pull Requests that ignore this guideline will be closed,
and may be aggregated into new Pull Requests without attribution.
